#! /bin/sh

cd /usr/share/screenruler
exec ./screenruler.rb
